Ruben Muscle Tracker v2
Open index.html to use it.
For install-as-app/PWA features, host the folder on HTTPS and choose Add to Home screen / Install.
All tracking data is stored locally in the browser. Use Export regularly for backup.
